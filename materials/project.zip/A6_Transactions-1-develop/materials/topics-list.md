# Topics list

Hello, student of School21!😉

To make it easier for you to navigate the material, we have prepared a list of topics that you will learn in this project.

We will study:

- key-value storages;
- hash table;
- binary search tree;
- balanced binary search tree;
- B-tree;
- measuring program/part of the program execution time.

Now, knowing what awaits you in this project, you can slowly begin to study the topics listed above.😇
