#include <cli/cli.cc>
#include <iostream>

using s21::CLI;
using std::cerr;
using std::cout;
using std::exception;
using std::invalid_argument;

int main(int argc, const char *argv[]) {
  int exit_code = 1;
  CLI cli;
  try {
    cli.Init(argc, argv);
    cli.Exec();
    exit_code = 0;
  } catch (const invalid_argument &ex) {
    cerr << "Input command error: " << ex.what() << "\n";
  } catch (const exception &ex) {
    cerr << "Exception occurred: " << ex.what() << "\n";
  }
  return exit_code;
}
