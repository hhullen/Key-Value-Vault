#ifndef TESTS_SETUP_PAYLOAD_TEST_FUNCTION_H_
#define TESTS_SETUP_PAYLOAD_TEST_FUNCTION_H_

#include <lib/vault/data_structure/vault_data.h>

s21::VaultData SetupCorrectPayload() {
  s21::VaultData payload;
  payload.SetField(0, "Vasilisa");
  payload.SetField(1, "Kadyk");
  payload.SetField(2, "1998");
  payload.SetField(3, "Uganda");
  payload.SetField(4, "451");
  return payload;
}

#endif // TESTS_SETUP_PAYLOAD_TEST_FUNCTION_H_
