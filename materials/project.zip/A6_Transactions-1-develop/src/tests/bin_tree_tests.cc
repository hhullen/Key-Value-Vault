#include <gtest/gtest.h>
#include <lib/bin_tree/bin_tree.h>

s21::VaultData SetupCorrectPayload() {
  s21::VaultData payload;
  payload.SetField(0, "Vasilisa");
  payload.SetField(1, "Kadyk");
  payload.SetField(2, "1998");
  payload.SetField(3, "Uganda");
  payload.SetField(4, "451");
  return payload;
}

TEST(BinTtree, Constructor) {
  EXPECT_NO_THROW(s21::SelfBalancingBinarySearchTree tree);
}

TEST(BinTtree, Set_method_with_payload) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_FALSE(err.HasError());
  err = tree.Set("key2", payload);
  EXPECT_FALSE(err.HasError());
  err = tree.Set("key3", payload);
  EXPECT_FALSE(err.HasError());
}

TEST(BinTtree, Set_method_with_existed_key) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_FALSE(err.HasError());
  err = tree.Set("key1", payload);
  EXPECT_TRUE(err.HasError());
}

TEST(BinTtree, Get_method_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_TRUE(!err.HasError());
  std::pair<s21::VaultData, s21::Err> out = tree.Get("key1");
  EXPECT_FALSE(out.second.HasError());
  EXPECT_EQ(out.first.GetRowAsString(), payload.GetRowAsString());
}

TEST(BinTtree, Get_method_not_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_FALSE(err.HasError());
  std::pair<s21::VaultData, s21::Err> out = tree.Get("UNEXISTED");
  EXPECT_TRUE(out.second.HasError());
}

TEST(BinTtree, IsExists_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_TRUE(tree.IsExists("key1"));
  EXPECT_FALSE(tree.IsExists("UNEXISTED"));
}

TEST(BinTtree, Delete_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_TRUE(tree.IsExists("key1"));
  EXPECT_FALSE(tree.Delete("UNEXISTED"));
  EXPECT_TRUE(tree.Delete("key1"));
  EXPECT_FALSE(tree.Delete("key1"));
}

TEST(BinTtree, Update_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  s21::VaultData payload_to_update;
  payload_to_update.SetField(0, "-");
  payload_to_update.SetField(1, "-");
  payload_to_update.SetField(2, "-");
  payload_to_update.SetField(3, "The hell");
  payload_to_update.SetField(4, "666");

  s21::VaultData payload_updated;
  payload_updated.SetField(0, "Vasilisa");
  payload_updated.SetField(1, "Kadyk");
  payload_updated.SetField(2, "1998");
  payload_updated.SetField(3, "The hell");
  payload_updated.SetField(4, "666");

  err = tree.Update("key1", payload_to_update);
  EXPECT_FALSE(err.HasError());
  EXPECT_TRUE(tree.IsExists("key1"));

  std::pair<s21::VaultData, s21::Err> out = tree.Get("key1");
  EXPECT_FALSE(out.second.HasError());
  EXPECT_EQ(out.first.GetRowAsString(), payload_updated.GetRowAsString());
}

TEST(BinTtree, GetKeys_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  tree.Set("key1", payload);
  tree.Set("key2", payload);

  s21::Channel<s21::Str> out;
  tree.GetKeys(out);

  s21::Str res = out.Get();
  EXPECT_EQ(res, "1) key1");
  res = out.Get();
  EXPECT_EQ(res, "2) key2");
}

TEST(BinTtree, Rename_method_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_TRUE(tree.IsExists("key1"));
  tree.Rename("key1", "new key");
  EXPECT_FALSE(tree.IsExists("key1"));
  EXPECT_TRUE(tree.IsExists("new key"));
}

TEST(BinTtree, Rename_method_not_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  EXPECT_TRUE(tree.IsExists("key1"));
  err = tree.Rename("UNEXISTED", "new key");
  EXPECT_TRUE(err.HasError());
  EXPECT_FALSE(tree.IsExists("new key"));
}

TEST(BinTtree, Rename_method_TO_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  tree.Set("key1", payload);
  tree.Set("new key", payload);

  EXPECT_TRUE(tree.IsExists("key1"));
  EXPECT_TRUE(tree.IsExists("new key"));
  s21::Err err = tree.Rename("key1", "new key");
  EXPECT_TRUE(err.HasError());
  EXPECT_TRUE(tree.IsExists("key1"));
  EXPECT_TRUE(tree.IsExists("new key"));
}

TEST(BinTtree, GetTTL_method_on_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  payload.SetDeathTimeMark(hhullen::Timer().TimepointSec() + 20);
  s21::Err err = tree.Set("key1", payload);

  std::pair<size_t, s21::Err> ttl = tree.GetTTL("key1");
  EXPECT_FALSE(ttl.second.HasError());
  EXPECT_GT(ttl.first, 0);
}

TEST(BinTtree, GetTTL_method_infinite) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  s21::Err err = tree.Set("key1", payload);

  std::pair<size_t, s21::Err> ttl = tree.GetTTL("key1");
  EXPECT_TRUE(ttl.second.HasError());
  EXPECT_EQ(ttl.first, 0);
}

TEST(BinTtree, GetTTL_method_on_not_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::SelfBalancingBinarySearchTree tree;
  payload.SetDeathTimeMark(1);
  s21::Err err = tree.Set("key1", payload);

  std::pair<size_t, s21::Err> ttl = tree.GetTTL("key1");
  EXPECT_TRUE(ttl.second.HasError());
  EXPECT_EQ(ttl.first, 0);
}

TEST(BinTtree, Find_method_on_existed) {
  s21::VaultData payload_1 = SetupCorrectPayload();
  s21::VaultData payload_2;
  payload_2.SetField(0, "Vasilisa");
  payload_2.SetField(1, "Vahmed");
  payload_2.SetField(2, "2002");
  payload_2.SetField(3, "Gagra");
  payload_2.SetField(4, "230");
  s21::SelfBalancingBinarySearchTree tree;
  tree.Set("key1", payload_1);
  tree.Set("key2", payload_2);

  s21::VaultData payload_to_find;
  payload_to_find.SetField(0, "Vasilisa");
  payload_to_find.SetField(1, "-");
  payload_to_find.SetField(2, "-");
  payload_to_find.SetField(3, "-");
  payload_to_find.SetField(4, "-");

  s21::Channel<s21::Str> out;
  tree.Find(out, payload_to_find);

  s21::Str res = out.Get();
  EXPECT_EQ(res, "1) key1");
  res = out.Get();
  EXPECT_EQ(res, "2) key2");
}

TEST(BinTtree, Find_method_on_expired) {
  s21::VaultData payload = SetupCorrectPayload();
  payload.SetDeathTimeMark(1);

  s21::SelfBalancingBinarySearchTree tree;
  tree.Set("key1", payload);

  s21::VaultData payload_to_find;
  payload_to_find.SetField(0, "Vasilisa");

  s21::Channel<s21::Str> out;
  tree.Find(out, payload_to_find);
  EXPECT_FALSE(out.HasContent());
}

TEST(BinTtree, ShowAll_method) {
  s21::VaultData payload_1 = SetupCorrectPayload();
  s21::VaultData payload_2;
  payload_2.SetField(0, "Vasilisa");
  payload_2.SetField(1, "Vahmed");
  payload_2.SetField(2, "2002");
  payload_2.SetField(3, "Gagra");
  payload_2.SetField(4, "230");

  s21::SelfBalancingBinarySearchTree tree;
  tree.Set("key1", payload_1);
  tree.Set("key2", payload_2);

  s21::Channel<s21::Str> out;
  tree.ShowAll(out);

  s21::Str res = out.Get();
  EXPECT_EQ(res, s21::VaultData::kHeader);
  res = out.Get();
  EXPECT_EQ(res, s21::Str("> 1\t" + payload_1.GetRowAsString()));
  res = out.Get();
  EXPECT_EQ(res, s21::Str("> 2\t" + payload_2.GetRowAsString()));
}

TEST(BinTtree, Upload_method_correct) {
  s21::SelfBalancingBinarySearchTree tree;
  std::pair<size_t, s21::Err> res =
      tree.Upload("../tests/datasets/data_correct_1000.txt");
  EXPECT_FALSE(res.second.HasError());
  EXPECT_EQ(res.second.What(), s21::Str());
  EXPECT_EQ(res.first, 1000);
}

TEST(BinTtree, Upload_method_not_existed_file) {
  s21::SelfBalancingBinarySearchTree tree;
  std::pair<size_t, s21::Err> res = tree.Upload("not_existed.txt");
  EXPECT_TRUE(res.second.HasError());
  EXPECT_EQ(res.first, 0);
}

TEST(BinTtree, Upload_method_partially_INcorrect_file) {
  s21::SelfBalancingBinarySearchTree tree;
  std::pair<size_t, s21::Err> res =
      tree.Upload("../tests/datasets/data_incorrect_fault_on_13.txt");
  EXPECT_TRUE(res.second.HasError());
  EXPECT_EQ(res.first, 12);
}

TEST(BinTtree, Export_method_correct) {
  s21::SelfBalancingBinarySearchTree tree;
  std::pair<size_t, s21::Err> res =
      tree.Upload("../tests/datasets/data_correct_1000.txt");

  res = tree.Export("test_export.txt");
  EXPECT_FALSE(res.second.HasError());
  EXPECT_EQ(res.first, 1000);
}

TEST(BinTtree, Export_method_unable_open_file) {
  s21::SelfBalancingBinarySearchTree tree;
  std::pair<size_t, s21::Err> res =
      tree.Upload("../tests/datasets/data_correct_1000.txt");

  res = tree.Export("");
  EXPECT_TRUE(res.second.HasError());
  EXPECT_EQ(res.first, 0);
}
