#include "bin_tree_tests.cc"
#include "hash_table_tests.cc"
