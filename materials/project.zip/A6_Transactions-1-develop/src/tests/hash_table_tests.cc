#include <lib/hash_table/container/hash_table_container.h>

#include "gtest/gtest.h"

using namespace s21;

TEST(HashTable, getHash) {
  HashTable h_table;
  size_t f_hash = h_table.getHash("jopa");
  size_t s_hash = h_table.getHash("jopa");
  size_t x_hash = h_table.getHash("Jopa");
  ASSERT_EQ(f_hash, s_hash);
  ASSERT_NE(f_hash, x_hash);
  EXPECT_TRUE(f_hash != 0);
}

// TEST(HashTable, Emplace) {
//   HashTable h_table;
//   auto refer = h_table.Emplace("jopa", "Very Important VAlue");
//   std::string str1 = refer->get()->value;
//   std::string str2 = "Very Important VAlue";
//   ASSERT_EQ(str1.compare(str2), 0);
// }

// TEST(HashTable, Emplace_size) {
//   HashTable h_table;
//   auto refer = h_table.Emplace("jopa", "Very Important VAlue");
//   std::string str1 = refer->get()->value;
//   std::string str2 = "Very Important VAlue";
//   ASSERT_EQ(h_table.Size(), 1);
// }

// TEST(HashTable, Find) {
//   HashTable h_table;
//   auto refer = h_table.Emplace("jopa", "Very Important VAlue");
//   auto refer2 = h_table.Emplace("dick", "Another One Very Important Value");
//   std::string str1 = h_table.Find("jopa")->get()->value;
//   std::string str2 = "Very Important VAlue";
//   std::string str3 = h_table.Find("dick")->get()->value;
//   std::string str4 = "Another One Very Important Value";
//   ASSERT_EQ(str1.compare(str2), 0);
//   ASSERT_EQ(str3.compare(str4), 0);
// }

// TEST(HashTable, Emplase_Find_Iterators) {
//   HashTable h_table;
//   auto iter1 = h_table.Emplace("jopa", "Very Important VAlue");
//   auto iter2 = h_table.Emplace("dick", "Another One Very Important Value");
//   auto iter3 = h_table.Find("jopa");
//   auto iter4 = h_table.Find("dick");
//   EXPECT_EQ(reinterpret_cast<size_t>(iter1),
//   reinterpret_cast<size_t>(iter3));
//   EXPECT_EQ(reinterpret_cast<size_t>(iter2),
//   reinterpret_cast<size_t>(iter4));
// }

// TEST(HashTable, Delete_Size) {
//   HashTable h_table;
//   h_table.Emplace("jopa", "Very Important VAlue");
//   h_table.Emplace("dick", "Another One Very Important Value");
//   int size_before = h_table.Size();
//   h_table.Delete("dick");
//   int size_after = h_table.Size();
//   EXPECT_EQ(size_before-size_after, 1);
// }

// TEST(HashTable, Delete_iterator) {
//   HashTable h_table;
//   auto iter = h_table.Emplace("dick", "Another One Very Important Value");
//   auto iter1 = h_table.Emplace("jopa", "Very Important VAlue");
//   auto iter2 = h_table.Delete("dick");
//   EXPECT_EQ(reinterpret_cast<size_t>(iter1),
//   reinterpret_cast<size_t>(iter2));
// }

// TEST(HashTable, Clear) {
//   HashTable h_table;
//   h_table.Emplace("dick", "Another One Very Important Value");
//   h_table.Emplace("jopa", "Very Important VAlue");
//   h_table.Clear();
//   for (Iterator iter = h_table.Begin(); iter != h_table.End(); iter++) {
//     EXPECT_TRUE(*iter == nullptr);
//   }
//   EXPECT_EQ(h_table.Size(), 0);
// }

// TEST(HashTable, Empty) {
//   HashTable h_table;
//   h_table.Emplace("dick", "Another One Very Important Value");
//   h_table.Emplace("jopa", "Very Important VAlue");
//   EXPECT_TRUE(!h_table.Empty());
//   h_table.Clear();
//   EXPECT_TRUE(h_table.Empty());
// }

// int main() {
//   ::testing::InitGoogleTest();
//   return RUN_ALL_TESTS();
// }