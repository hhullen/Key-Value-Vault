#include "setup_payload_test_function.h"
#include <gtest/gtest.h>
#include <lib/hash_table/hash_table.h>

TEST(HashTable, Constructor) { EXPECT_NO_THROW(s21::HashTable ht); }

TEST(HashTable, Set_method_with_payload) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_FALSE(err.HasError());
  err = ht.Set("key2", payload);
  EXPECT_FALSE(err.HasError());
  err = ht.Set("key3", payload);
  EXPECT_FALSE(err.HasError());
}

TEST(HashTable, Set_method_with_existed_key) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_FALSE(err.HasError());
  err = ht.Set("key1", payload);
  EXPECT_TRUE(err.HasError());
}

TEST(HashTable, Get_method_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_TRUE(!err.HasError());
  std::pair<s21::VaultData, s21::Err> out = ht.Get("key1");
  EXPECT_FALSE(out.second.HasError());
  EXPECT_EQ(out.first.GetRowAsString(), payload.GetRowAsString());
}

TEST(HashTable, Get_method_not_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_FALSE(err.HasError());
  std::pair<s21::VaultData, s21::Err> out = ht.Get("UNEXISTED");
  EXPECT_TRUE(out.second.HasError());
}

TEST(HashTable, IsExists_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_TRUE(ht.IsExists("key1"));
  EXPECT_FALSE(ht.IsExists("UNEXISTED"));
}

TEST(HashTable, Delete_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_TRUE(ht.IsExists("key1"));
  EXPECT_FALSE(ht.Delete("UNEXISTED"));
  EXPECT_TRUE(ht.Delete("key1"));
  EXPECT_FALSE(ht.Delete("key1"));
}

TEST(HashTable, Update_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  s21::VaultData payload_to_update;
  payload_to_update.SetField(0, "-");
  payload_to_update.SetField(1, "-");
  payload_to_update.SetField(2, "-");
  payload_to_update.SetField(3, "The hell");
  payload_to_update.SetField(4, "666");

  s21::VaultData payload_updated;
  payload_updated.SetField(0, "Vasilisa");
  payload_updated.SetField(1, "Kadyk");
  payload_updated.SetField(2, "1998");
  payload_updated.SetField(3, "The hell");
  payload_updated.SetField(4, "666");

  err = ht.Update("key1", payload_to_update);
  EXPECT_FALSE(err.HasError());
  EXPECT_TRUE(ht.IsExists("key1"));

  std::pair<s21::VaultData, s21::Err> out = ht.Get("key1");
  EXPECT_FALSE(out.second.HasError());
  EXPECT_EQ(out.first.GetRowAsString(), payload_updated.GetRowAsString());
}

TEST(HashTable, GetKeys_method) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  ht.Set("key1", payload);
  ht.Set("key2", payload);

  s21::Channel<s21::Str> out;
  ht.GetKeys(out);

  s21::Str res = out.Get();
  EXPECT_EQ(res, "1) key1");
  res = out.Get();
  EXPECT_EQ(res, "2) key2");
}

TEST(HashTable, Rename_method_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_TRUE(ht.IsExists("key1"));
  ht.Rename("key1", "new key");
  EXPECT_FALSE(ht.IsExists("key1"));
  EXPECT_TRUE(ht.IsExists("new key"));
}

TEST(HashTable, Rename_method_not_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  EXPECT_TRUE(ht.IsExists("key1"));
  err = ht.Rename("UNEXISTED", "new key");
  EXPECT_TRUE(err.HasError());
  EXPECT_FALSE(ht.IsExists("new key"));
}

TEST(HashTable, Rename_method_TO_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  ht.Set("key1", payload);
  ht.Set("new key", payload);

  EXPECT_TRUE(ht.IsExists("key1"));
  EXPECT_TRUE(ht.IsExists("new key"));
  s21::Err err = ht.Rename("key1", "new key");
  EXPECT_TRUE(err.HasError());
  EXPECT_TRUE(ht.IsExists("key1"));
  EXPECT_TRUE(ht.IsExists("new key"));
}

TEST(HashTable, GetTTL_method_on_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  payload.SetDeathTimeMark(hhullen::Timer().TimepointSec() + 20);
  s21::Err err = ht.Set("key1", payload);

  std::pair<size_t, s21::Err> ttl = ht.GetTTL("key1");
  EXPECT_FALSE(ttl.second.HasError());
  EXPECT_GT(ttl.first, 0);
}

TEST(HashTable, GetTTL_method_infinite) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  s21::Err err = ht.Set("key1", payload);

  std::pair<size_t, s21::Err> ttl = ht.GetTTL("key1");
  EXPECT_TRUE(ttl.second.HasError());
  EXPECT_EQ(ttl.first, 0);
}

TEST(HashTable, GetTTL_method_on_not_existed) {
  s21::VaultData payload = SetupCorrectPayload();
  s21::HashTable ht;
  payload.SetDeathTimeMark(1);
  s21::Err err = ht.Set("key1", payload);

  std::pair<size_t, s21::Err> ttl = ht.GetTTL("key1");
  EXPECT_TRUE(ttl.second.HasError());
  EXPECT_EQ(ttl.first, 0);
}

TEST(HashTable, Find_method_on_existed) {
  s21::VaultData payload_1 = SetupCorrectPayload();
  s21::VaultData payload_2;
  payload_2.SetField(0, "Vasilisa");
  payload_2.SetField(1, "Vahmed");
  payload_2.SetField(2, "2002");
  payload_2.SetField(3, "Gagra");
  payload_2.SetField(4, "230");
  s21::HashTable ht;
  ht.Set("key1", payload_1);
  ht.Set("key2", payload_2);

  s21::VaultData payload_to_find;
  payload_to_find.SetField(0, "Vasilisa");
  payload_to_find.SetField(1, "-");
  payload_to_find.SetField(2, "-");
  payload_to_find.SetField(3, "-");
  payload_to_find.SetField(4, "-");

  s21::Channel<s21::Str> out;
  ht.Find(out, payload_to_find);

  s21::Str res = out.Get();
  EXPECT_EQ(res, "1) key1");
  res = out.Get();
  EXPECT_EQ(res, "2) key2");
}

TEST(HashTable, Find_method_on_expired) {
  s21::VaultData payload = SetupCorrectPayload();
  payload.SetDeathTimeMark(1);

  s21::HashTable ht;
  ht.Set("key1", payload);

  s21::VaultData payload_to_find;
  payload_to_find.SetField(0, "Vasilisa");

  s21::Channel<s21::Str> out;
  ht.Find(out, payload_to_find);
  EXPECT_FALSE(out.HasContent());
}

TEST(HashTable, ShowAll_method) {
  s21::VaultData payload_1 = SetupCorrectPayload();
  s21::VaultData payload_2;
  payload_2.SetField(0, "Vasilisa");
  payload_2.SetField(1, "Vahmed");
  payload_2.SetField(2, "2002");
  payload_2.SetField(3, "Gagra");
  payload_2.SetField(4, "230");

  s21::HashTable ht;
  ht.Set("key1", payload_1);
  ht.Set("key2", payload_2);

  s21::Channel<s21::Str> out;
  ht.ShowAll(out);

  s21::Str res = out.Get();
  EXPECT_EQ(res, s21::VaultData::kHeader);
  res = out.Get();
  EXPECT_EQ(res, s21::Str("> 1\t" + payload_1.GetRowAsString()));
  res = out.Get();
  EXPECT_EQ(res, s21::Str("> 2\t" + payload_2.GetRowAsString()));
}

TEST(HashTable, Upload_method_correct) {
  s21::HashTable ht;
  std::pair<size_t, s21::Err> res =
      ht.Upload("../tests/datasets/data_correct_1000.txt");
  EXPECT_FALSE(res.second.HasError());
  EXPECT_EQ(res.second.What(), s21::Str());
  EXPECT_EQ(res.first, 1000);
}

TEST(HashTable, Upload_method_not_existed_file) {
  s21::HashTable ht;
  std::pair<size_t, s21::Err> res = ht.Upload("not_existed.txt");
  EXPECT_TRUE(res.second.HasError());
  EXPECT_EQ(res.first, 0);
}

TEST(HashTable, Upload_method_partially_INcorrect_file) {
  s21::HashTable ht;
  std::pair<size_t, s21::Err> res =
      ht.Upload("../tests/datasets/data_incorrect_fault_on_13.txt");
  EXPECT_TRUE(res.second.HasError());
  EXPECT_EQ(res.first, 12);
}

TEST(HashTable, Export_method_correct) {
  s21::HashTable ht;
  std::pair<size_t, s21::Err> res =
      ht.Upload("../tests/datasets/data_correct_1000.txt");

  res = ht.Export("test_export.txt");
  EXPECT_FALSE(res.second.HasError());
  EXPECT_EQ(res.first, 1000);
}

TEST(HashTable, Export_method_unable_open_file) {
  s21::HashTable ht;
  std::pair<size_t, s21::Err> res =
      ht.Upload("../tests/datasets/data_correct_1000.txt");

  res = ht.Export("");
  EXPECT_TRUE(res.second.HasError());
  EXPECT_EQ(res.first, 0);
}
