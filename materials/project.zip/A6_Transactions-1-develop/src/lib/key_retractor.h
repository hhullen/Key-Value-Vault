#ifndef SRC_LIB_KEY_RETRACTOR_H_
#define SRC_LIB_KEY_RETRACTOR_H_

#include <utility>

namespace s21 {

template <class Key, class Value> class PairKeyRetractor {
public:
  const Key &operator()(const std::pair<Key, Value> &value) {
    return value.first;
  }
};

} // namespace s21

#endif // SRC_LIB_KEY_RETRACTOR_H_
