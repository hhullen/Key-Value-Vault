#ifndef SRC_LIB_HASH_TABLE_HASH_TABLE_H_
#define SRC_LIB_HASH_TABLE_HASH_TABLE_H_

#include <include/StrPlus/str_plus.h>
#include <include/timer/timer.h>
#include <lib/key_retractor.h>
#include <lib/vault/vault_interface.h>

#include <fstream>

#include "container/hash_table.h"

using std::getline;
using std::ifstream;
using std::ofstream;
using std::to_string;

namespace s21 {

class HashTable : public IVault {
public:
  using Container =
      hhullen::HashTableContainer<std::pair<Str, VaultData>, Str,
                                  PairKeyRetractor<Str, VaultData>>;
  using Iterator = Container::Iterator;

  Err Set(const Str &key, const VaultData &value);
  pair<VaultData, Err> Get(const Str &key);
  bool IsExists(const Str &key);
  bool Delete(const Str &key);
  Err Update(const Str &key, const VaultData &value);
  void GetKeys(Channel<Str> &out);
  Err Rename(const Str &key_old, const Str &key_new);
  pair<size_t, Err> GetTTL(const Str &key);
  void Find(Channel<Str> &out, const VaultData &value);
  void ShowAll(Channel<Str> &out);
  pair<size_t, Err> Upload(const Str &file_path);
  pair<size_t, Err> Export(const Str &file_path);

private:
  Container container_;

  Iterator GetIfExistsOrAlive(const Str &key);
  bool IsExpired(size_t timemark);
};

} // namespace s21

#endif // SRC_LIB_HASH_TABLE_HASH_TABLE_H_